import ResponseModel from './Response.model';

export { ResponseModel };
